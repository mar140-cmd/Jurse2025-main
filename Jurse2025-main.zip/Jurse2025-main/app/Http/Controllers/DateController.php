<?php

namespace App\Http\Controllers;

class DateController extends Controller
{
    function index()
    {
        return view("date.index");
    }
}
