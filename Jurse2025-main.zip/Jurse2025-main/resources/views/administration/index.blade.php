@extends('layouts.app')

@section('content')
  <div class="container">
    <h2>You're successfully logged in!</h2>
    <p>What would you like to do next?</p>
  </div>
@endsection