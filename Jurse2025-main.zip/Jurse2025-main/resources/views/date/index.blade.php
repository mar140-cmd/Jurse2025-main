<!DOCTYPE html>
<html lang="en-US" dir="ltr">
<head>
  <?php include('head.php'); ?>
</head>
<body class="stretched has-plugin-easing has-plugin-bootstrap device-md">
  <header><?php include('header.php'); ?></header>

  <section class="table-container py-1 mb-5">
    <div class="container">
      <h2>date </h2>
      <table class="table">
        <thead>
          <tr>
            <th class="w-50">Action</th>
            <th class="w-50">Deadline</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>test 1</td>
            <td> 2023</td> </tr>
          <tr>
            <td>Test 2</td>
            <td> 2023</td> </tr>
          <tr>
          
        </tbody>
      </table>
    </div>
  </section>


</body>
</html>
